({
    
	myAction : function(component, event, helper) {
		location.reload();
	}
})