({
	helperMethod : function() {
	var foo = document.getElementById('Test');
document.close();
        'foo' instanceof string;
        if('bar' instanceof string){}
        window.localStorage();
        Aura.something();
        var webSocket = new WebSocket("ws://www.salesforce.com/OAuthProtectedResource");
	}
    
     

	
})