({
	// Your renderer method overrides go here
    alert:function(){alert('Renderer');}

})